#!/bin/bash

mon=$(date | awk '{print $3}')
year=$(date | awk '{print $4}')

let "prev=year-1" "next=year+1"

cal $mon $prev
cal $mon $year
cal $mon $next
