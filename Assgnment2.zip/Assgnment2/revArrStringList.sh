#!/bin/bash


echo 'Enter array of Strings : '
read -a arr

min=0
max=`expr ${#arr[@]} - 1`
x=$max
while (( $min <= $max ))
do
	newArr[$min]=${arr[$max]}
	newArr[$max]=${arr[$min]}
	(( min++ ))
	(( max-- ))
done

max=$x

for (( i=0; i<=max; i++ ))
do
	rev=""
	str=${newArr[$i]}
	let "len=${#str} -1"
	for (( j=$len; j>=0; j-- ))
	do
		rev="$rev${str:$j:1}"
	done
	newArr[$i]=$rev
done

echo ${newArr[@]}
