#!/bin/bash

echo 'Enter num1 : '
read num1
echo 'Enter num2 : '
read num2

let "prodlet=num1*num2"

prodExp=$(expr $num1 \* $num2)

echo 'Let : '
echo $prodlet 
echo 'Expr : '
echo $prodExp
echo 'BC : '
echo $num1 \* $num2 | bc
