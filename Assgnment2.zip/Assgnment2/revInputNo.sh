#!/bin/bash

echo 'Enter a number : '
read num
n=$num
sum=0
rem=0
while (( $n > 0 ))
do
	rem=`expr $n % 10`
	sum=`expr $sum \* 10`
	sum=`expr $sum + $rem`
	n=`expr $n / 10`
done
echo 'Reverse : ' $sum

