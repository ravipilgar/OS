#!/bin/bash

echo 'Enter the range till you want to calculate the Fibonaccci Series : '
read range
i=1
prev=0
newprev=0
while (( $i+$prev < $range ))
do
	echo $(expr $prev + $i)
	newprev=$prev
	prev=$i
	i=$(expr $newprev + $i)
done
