#!/bin/bash

echo 'Enter num1 : '
read num1
echo 'Enter num2 : '
read num2
echo 'Enter num3 : '
read num3

(( avg = (( $num1+$num2+$num3 ))/3 ))
echo 'Average : '$avg
